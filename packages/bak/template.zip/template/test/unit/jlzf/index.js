import zqzf from './zqzf';

export default [zqzf]