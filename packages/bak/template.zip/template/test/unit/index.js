import base from './base/index';
import jlzf from './jlzf/index';

export default [...base,...jlzf];


