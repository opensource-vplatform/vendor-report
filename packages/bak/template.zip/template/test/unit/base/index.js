import base from './base';

export default [base]