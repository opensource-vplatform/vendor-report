import BaseTemplate from '../BaseTemplate';

class StaticTemplate extends BaseTemplate{

    constructor(template){
        super(template);
    }

}

export default StaticTemplate;