import BaseTemplate from '../BaseTemplate';

class FieldTemplate extends BaseTemplate{

    constructor(template){
        super(template);
    }

}

export default FieldTemplate;